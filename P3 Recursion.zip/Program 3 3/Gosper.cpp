/* 
 * Chelsea Ip Tze Hwan
 * Professor Fukuda
 * CSS 342
 * Programming Assignment #3
 * 
 * This program draws hexagonal Gosper curves by calling its methods (leftCurve &
 * rightCurve) recursively.
 *
 * Created on 22 October 2018, 15:31
 */


#include "Gosper.h"

const int RIGHT = -60;
const int LEFT = 60;

Gosper::Gosper(float initX, float initY, float initAngle)
: Turtle(initX, initY, initAngle) {
}


// Draw a level-1 left curve with dist d

void Gosper::leftCurve(int level, float d) {
    if (level > 0) {
        leftCurve(level - 1, d);
        turn(60);
        rightCurve(level - 1, d);
        turn(60);
        turn(60);
        rightCurve(level - 1, d);
        turn(-60);
        leftCurve(level - 1, d);
        turn(-60);
        turn(-60);
        leftCurve(level - 1, d);
        leftCurve(level - 1, d);
        turn(-60);
        rightCurve(level - 1, d);
        turn(60);

    } else
        draw(d);
}

//------------------------------ rightCurve ---------------------------------
// draw a level-l right curve with dist d

void Gosper::rightCurve(int level, float d) {
    if (level > 0) {
        turn(-60);
        leftCurve(level - 1, d);
        turn(60);
        rightCurve(level - 1, d);
        rightCurve(level - 1, d);
        turn(60);
        turn(60);
        rightCurve(level - 1, d);
        turn(60);
        leftCurve(level - 1, d);
        turn(-60);
        turn(-60);
        leftCurve(level - 1, d);
        turn(-60);
        rightCurve(level - 1, d);

    } else
        draw(d);
}


