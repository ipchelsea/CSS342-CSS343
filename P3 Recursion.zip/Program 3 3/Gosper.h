
/* 
 * File:   Gosper.h
 * Author: chelseaiptzehwan
 *
 * Created on 22 October 2018, 15:31
 */

//GOSPER CLASS
#ifndef GOSPER_H
#define GOSPER_H

#include <iostream>
#include "Turtle.h"
#include <math.h>

using namespace std;

//---------------------------------------------------------------------------
// Gosper curve:
//   -- leftCurve: draws a left Gosper arrowhead at a given level
//   -- rightCurve: draws a right Gosper arrowhead at a given level
//
// Assumptions:
//   -- Level l is defined as an integer.
//   -- Distance d is define as a float.
//   -- Outputs are in postscript format.
//---------------------------------------------------------------------


class Gosper : Turtle {
public:
  Gosper( float initX=0.0, float initY=0.0, float initAngle=0.0 );
  void leftCurve( int l, float d );  //draw a level-l left curve with dist d
  void rightCurve( int l, float d ); //draw a level-l right curve with dist d}

};

#endif /* GOSPER_H */

