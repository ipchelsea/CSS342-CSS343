/*
 * Chelsea Ip Tze Hwan
 * Programming Assignment #6
 * CSS 342
 * Muneheiro Fukuda
 * November 20, 2018
 * This programming assignment implements the skiplist and compares performance with dlist,
 * mtflist, and translist that I have implemented in Lab 5. We only need to implement two methods
 * which are the insert method and remove method. The insert algorithm starts off with inserting a new
 * item in level 0 before it transverse up to a one-level higher list to insert
 * the same new item if rand()%2 returns a 1. Otherwise stop creating upper layers.
 * The deletion algorithm starts off with the search pointer pointing at zero, linking it with 
 * left and right items before creating a temporary pointer that points to it while p traverses 
 * up the list to delete the upper items
 * 
 */

#include <stdlib.h>
#include "slist.h"

template<class Object>
SList<Object>::SList() {
    init();
}

template<class Object>
SList<Object>::SList(const SList &rhs) {
    init();
    *this = rhs;
}

template<class Object>
void SList<Object>::init() {
    for (int i = 0; i < LEVEL; i++) { // for each level
        // create the left most dummy nodes;
        header[i] = new SListNode<Object>;
        header[i]->prev = NULL;
        header[i]->down = (i > 0) ? header[i - 1] : NULL;
        header[i]->up = NULL;
        if (i > 0) header[i - 1]->up = header[i];

        // create the right most dummy nodes;
        header[i]->next = new SListNode<Object>;
        header[i]->next->next = NULL;
        header[i]->next->prev = header[i];
        header[i]->next->down = (i > 0) ? header[i - 1]->next : NULL;
        header[i]->next->up = NULL;
        if (i > 0) header[i - 1]->next->up = header[i]->next;
    }

    // reset cost.
    cost = 0;
}

template<class Object>
SList<Object>::~SList() {
    clear(); // delete items starting 1st
    for (int i = 0; i < LEVEL; i++) {
        delete header[i]->next; // delete the right most dummy
        delete header[i]; // delete the left most dummy
    }
}

template<class Object>
bool SList<Object>::isEmpty() const {
    return ( header[0]->next->next == NULL);
}

template<class Object>
int SList<Object>::size() const {
    SListNode<Object> *p = header[0]->next; // at least the right most dummy
    int size = 0;

    for (; p->next != NULL; p = p->next, ++size);
    return size;
}

template<class Object>
void SList<Object>::clear() {
    for (int i = 0; i < LEVEL; i++) { // for each level
        SListNode<Object> *p = header[i]->next; // get the 1st item
        while (p->next != NULL) { // if this is not the left most
            SListNode<Object> *del = p;
            p = p->next;
            delete del; // delete the current item
        }

        header[i]->next = p; // p now points to the left most
    } // let the right most point to it
}

template<class Object>
void SList<Object>::insert(const Object &obj) {
    // right points to the level-0 item before which a new object is inserted.
    SListNode<Object> *right = searchPointer(obj);
    SListNode<Object> *up = NULL;
    SListNode<Object> *bottom = new SListNode<Object>;

    int numLevel = 0;

    if (right->next != NULL && right->item == obj)
        // there is an identical object
        return;

    //Step 0:inserting item in the lowest level(0) first before going to a higher level
    bottom->item = obj;
    right->prev->next = bottom;
    bottom->prev = right->prev; //connect to the left
    bottom->next = right; //make the new item connect to the right
    right->prev = bottom;
    numLevel++;

    //Step 1:decide whether the same item should be inserted in one-level higher list
    int random = rand() % 2;

    while (random == 1) //proceed if it returns 1, otherwise stop creating upper layers
    {
        if (numLevel == LEVEL) {
            random = 0;
            return;
        }
        //Step 2: Inserting the same new item in a one-level higher list
        up = bottom->prev; //and start moving left toward the inf at the current level

        while (up->up == NULL) { //Step 3: Shift up to the same item in the next higher list
            up = up->prev;
        }

        //Step 4: Move right just one time, to the next item
        up = up->up;
        up = up->next;

        //Step 5: Insert the new item in front of the current item, we create an upper item first.
        SListNode<Object>*currentNode = new SListNode<Object>;
        currentNode->item = obj;

        //When linking vertically, first connect to the upper item
        up->prev->next = currentNode;
        currentNode->prev = up->prev;

        currentNode->next = up;
        up->prev = currentNode;

        //connect to the lower item
        bottom->up = currentNode;
        currentNode->down = bottom;

        bottom = currentNode;
        numLevel++;

        random = rand() % 2;
    }

}

template<class Object>
bool SList<Object>::find(const Object &obj) {
    // p oints to the level-0 item close to a given object
    SListNode<Object> *p = searchPointer(obj);

    return ( p->next != NULL && p->item == obj); // true if obj was found
}

template<class Object>
SListNode<Object> *SList<Object>::searchPointer(const Object &obj) {
    SListNode<Object> *p = header[LEVEL - 1]; // start from the top left
    while (p->down != NULL) { // toward level 0
        p = p->down; // shift down once
        cost++;

        if (p->prev == NULL) { // at the left most item
            if (p->next->next == NULL) // no intermediate items
                continue;
            else { // some intermadiate items
                if (p->next->item <= obj) // if 1st item <= obj
                    p = p->next; // shift right to item 1
                cost++;
            }
        }

        while (p->next->next != NULL && p->next->item <= obj) {
            // shift right through intermediate items as far as the item value <= obj
            p = p->next;
            cost++;
        }
    }

    // now reached the bottom. shift right once if the current item < obj
    if (p->prev == NULL || p->item < obj) {
        p = p->next;
        cost++;
    }
    return p; // return the pointer to an item >= a given object.
}

template<class Object>
void SList<Object>::remove(const Object &obj) {
    // p points to the level-0 item to delete
    SListNode<Object> *p = searchPointer(obj);

    // validate if p is not the left most or right most and exactly contains the
    // item to delete
    if (p->prev == NULL || p->next == NULL || p->item != obj)
        return;

    while (p->up != NULL) { //while the p element is not a null and has a higher level above
        SListNode<Object> *temp = p; //make a temporary pointer
        p->prev->next = p->next; //make the left neighbor and the right neighbor point to each other
        p->next->prev = p->prev;
        p = p->up; //move p up
        delete temp; //delete node temp is pointing to
    }
    if (p->up == NULL) {//in case it reaches a single node or the top node
        p->prev->next = p->next; //make the left neighbor and the right neighbor point to each other
        p->next->prev = p->prev;
        delete p;
    }
}

template<class Object>
const SList<Object> &SList<Object>::operator=(const SList &rhs) {
    if (this != &rhs) { // avoid self-assignment
        clear(); // deallocate old items

        int index;
        SListNode<Object> *rnode;
        for (index = 0, rnode = rhs.header[0]->next; rnode->next != NULL;
                rnode = rnode->next, ++index)
            insert(rnode->item);

        cost = rhs.cost;
    }
    return *this;
}

template<class Object>
int SList<Object>::getCost() const {
    return cost;
}

template<class Object>
void SList<Object>::show() const {
    cout << "contents:" << endl;
    for (SListNode<Object> *col = header[0]; col != NULL; col = col->next) {
        SListNode<Object> *row = col;
        for (int level = 0; row != NULL && level < LEVEL; level++) {
            if (row->prev == NULL)
                cout << "-inf\t";
            else if (row->next == NULL)
                cout << "+inf\t";
            else
                cout << row->item << "\t";
            row = row->up;
        }
        cout << endl;
    }
}


