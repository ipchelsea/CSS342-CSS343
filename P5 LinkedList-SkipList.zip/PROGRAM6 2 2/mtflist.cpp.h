template<class Object>
int MtfList<Object>::find( const Object &obj ) {
  DListNode<Object> *top = DList<Object>::header->next;
  DListNode<Object> *found = top;
  //found is found
  for ( ; found != NULL && found->item != obj;  found = found->next )
    ++DList<Object>::cost;

  if ( found == NULL ) {
    return -1;
  }// if item is not found

  if ( found == top ) {
    return 0; 
  }// no need to move to front     
  
  if( found->next == NULL) {
      found->prev->next = NULL;
  }
  else {
      found->prev->next = found ->next;
      found->next->prev = found-> prev;
  }
  
  found->next = top;
  top->prev = found;
  
  found->prev = DList<Object>::header;
  DList<Object>::header->next = found;
  
  
  
  return 0;
}

 