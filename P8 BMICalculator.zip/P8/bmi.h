/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   bmi.h
 * Author: chelseaiptzehwan
 *
 * Created on 10 January 2019, 14:28
 */

#ifndef BMI_H
#define BMI_H
#include <string>

using namespace std;

class BMI {
public:
    BMI(const string& newName, int newAge, double newWeight, double newHeight);
    BMI(const string& newName, double newWeight, double newHeight);
    double getBMI() const;
    string getStatus() const;
    string getName() const;
    int getAge() const;
    double getWeight()const;
    double getHeight()const;
private:
    string name;
    int age;
    double weight;
    double height;
};

#endif




