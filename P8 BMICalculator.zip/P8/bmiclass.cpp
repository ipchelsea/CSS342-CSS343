/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include "bmi.h"
using namespace std;

int main() 
{
    BMI bmi1("Chelsea Ip", 20, 126, 64.96);
    cout <<"The BMI for " <<bmi1.getName()<< " is "
            <<bmi1.getBMI() << " "<<bmi1.getStatus() << endl;
    
    BMI bmi2("Susan King", 215, 70);
    cout << "The BMI for " << bmi2.getName() << " is "
            <<bmi2.getBMI() << " " + bmi2.getStatus() << endl;
    return 0;
}
          
         
