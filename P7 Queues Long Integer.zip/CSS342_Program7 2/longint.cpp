/*
 * Chelsea Ip Tze Hwan
 * Programming Assignment #7
 * CSS 342
 * Munehiro Fukuda
 * December 10, 2018
 *
 * Designed a LongInt class that maintains a very long integer with a deque of
 * characters. I also implemented operators <,<=,>,>=,==, and != to
 * compare between the left-hand and right-hand operands. A private function called compareTo
 * checks the size, then compares the "-" sign for both lhs and rhs values. Created another substract
 * function to call in the minus operator for lhs-rhs.
 * Examine lhs and rhs digit by digit from the tail of their deque and 
 * remove 0's in front of number.
 *
 */


#include "longint.h"
#include <iostream>
#include <string>
#include <algorithm>

LongInt::LongInt(const string str) {

    int index = 0;

    if (str[index] == '-') {//if the first index is '-' sign then it's negative
        index = 1;
        negative = true;
    }

    while (index < str.size()) {
        //must read characters '0 through '9'
        if (isdigit(str[index])) {

            digits.addBack(str[index]);

        }
        index++;
    }

    remove0s();


    if (str[0] == '-') {
        negative = true;
        //digits.addFront('-');
    } else {
        negative = false;
    }
}

//Copy constructor, assigns objects to equal to rhs
LongInt::LongInt(const LongInt& rhs) {
    digits.clear();
    digits = rhs.digits;
    negative = rhs.negative;
}

// the default constructor that initializes the object to 0.

LongInt::LongInt() {
    digits.clear();
    digits.addBack('0');
    negative = false;
}
//destructor should deallocate all Deque items.
LongInt::~LongInt() {
    digits.~Deque();
}

//if only 1 zero in front, return. Otherwise, if there are multiple zeroes following it,
//remove. Wrong outputs include -0, 00000, -000
void LongInt::remove0s() {

    if (digits.size() == 1 && digits.getFront() == '0') {
        return;
    }

    while (digits.size() > 1 && digits.getFront() == '0') {
        digits.removeFront();
    }

}

//INPUT
//must read characters '0' through '9' from the keyboard as well as accept '-'
//if it's the first character, skip all the other characters

istream& operator>>(istream &in, LongInt &rhs) {
    //first create string to receive input from user
    string str1;
    in >> str1;

    //you can use LongInt(string str) constructor
    rhs = LongInt(str1);
    return in;
}
//OUTPUT
//Must print out a given LongInt Object's digits as an integer
//If the LongInt object digits is empty or 0, it should be printed out as 0
//without negative sign 

ostream& operator<<(ostream& out, const LongInt &rhs) {

    Deque<char> result = rhs.digits;
    if (rhs.negative)
        cout << '-';
    while (result.isEmpty() == false) {
        out << result.removeFront();

    }

    return out;

}

//Implement operators <, <=, >, >=, ==, and !=. 

const LongInt& LongInt::operator=(const LongInt &rhs) {
    negative = rhs.negative;
    digits = rhs.digits;
    return *this;
}

//Created a max function to choose the large deque size
int LongInt::max(int a, int b) const {
    if (a < b) {
        return b;
    }
    return a;
}

//Operator+
//First, consider four different cases:
//positive lhs + positive rhs means ans = lhs + rhs.
//positive lhs + negative rhs means ans = lhs - rhs. You should call operator-.
//negative lhs + positive rhs means ans = rhs - lhs. You should call operator-.
//negative lhs + negative rhs means ans = -(lhs + rhs). 
//Apply operator+ and thereafter set a negative sign.
LongInt LongInt::operator+(const LongInt &rhs) const {

    LongInt result;
    string str = "";
    
    if (negative && rhs.negative) {//lhs-rhs, here calls minus operator
        LongInt lhs;
        LongInt copyrhs;

        lhs.negative = true;
        lhs.digits = digits;

        copyrhs.negative = false;
        copyrhs.digits = rhs.digits;

        result = lhs - copyrhs; //calls minus operator here
        return result;
    }

    if (!negative && rhs.negative) 
    {
        LongInt lhs;
        LongInt copyrhs;

        lhs.negative = false;
        lhs.digits = digits;


        copyrhs.negative = false;
        copyrhs.digits = rhs.digits;

        result = lhs - copyrhs;//lhs-rhs (calls minus operator here)
        return result;
    } else if (negative && !rhs.negative) //rhs-lhs, minus operator called here
    {
        LongInt lhs;
        LongInt copyrhs;

        lhs.negative = false;
        lhs.digits = digits;

        copyrhs.negative = false;
        copyrhs.digits = rhs.digits;

        result = copyrhs - lhs;
        return result;
    }
    
    //lhs+rhs
    Deque<char> right = rhs.digits;
    Deque<char> left = digits;


    int maxsize = max(right.size(), left.size());

    int borrow = 0;

    int i = 0;
    for (; i < maxsize; i++) {
        //get int values
        int c1, c2;
        if (left.isEmpty() == false)
            c1 = left.removeBack() - 48;
        else
            c1 = 0;
        if (right.isEmpty() == false)
            c2 = right.removeBack() - 48;
        else
            c2 = 0;

        int sum = (c1 + c2 + borrow) % 10;
        borrow = (c1 + c2 + borrow) / 10;//checks if carry has 0 or 1


        str = string(1, 48 + sum) + str;

    }

    if (borrow > 0)
        str = "1" + str;
    Deque<char> returnDeque; //adding it to the deque from the back
    for (int i = 0; i < str.length(); i++)
        returnDeque.addBack(str[i]);
    result.digits = returnDeque;
    result.negative = false;
    return result;
}


//Operator-:
//positive lhs - positive rhs means ans = lhs - rhs.
//positive lhs - negative rhs means ans = lhs + rhs. You should call operator+.
//negative lhs - positive rhs means ans = -(lhs + rhs). 
//negative lhs - negative rhs means ans = rhs - lhs.
LongInt LongInt::operator-(const LongInt &rhs) const {

    string str = "";
    LongInt result;

    if (!negative && rhs.negative) //if lhs and rhs is not negative
    {
        LongInt lhs;
        LongInt copyrhs;


        lhs.negative = false;
        lhs.digits = digits;


        copyrhs.negative = false;
        copyrhs.digits = rhs.digits;

        result = lhs + copyrhs;
        return result;
    } else if (negative && !rhs.negative) //if lhs is positive, rh is negative
    {
        LongInt lhs;
        LongInt copyrhs;

        lhs.negative = false;
        lhs.digits = digits;

      
        copyrhs.negative = false;
        copyrhs.digits = rhs.digits;

        result = lhs + copyrhs;
        result.negative = true;
        return result;
    } else if (negative && rhs.negative) //if lhs is negative & rhs is negative
    {

        if (*this > rhs) {
            return subtract(rhs);
        } else if (*this < rhs) {
            return rhs.subtract(*this);

        } else // zeros out
        {
            Deque<char> returnDeque;
            returnDeque.addBack(48);
            result.digits = returnDeque;
            result.negative = false;
            return result;
        }
    } else if (!negative && !rhs.negative) //if lhs and rhs are both positive
    {
        LongInt lhs;
        LongInt copyrhs;

        lhs.negative = false;
        lhs.digits = digits;

        copyrhs.negative = false;
        copyrhs.digits = rhs.digits;

        if (lhs < rhs) { 
            return subtract(rhs);
        } else if (lhs > rhs) {
            return rhs.subtract(*this);
        } else 
        {
            Deque<char> returnDeque;
            returnDeque.addBack('0');
            result.digits = returnDeque;
            result.negative = false;
            return result;
        }
    }

    return subtract(rhs);
}
//made another function to call in operator minus.
//performs the basic minus operation here
LongInt LongInt::subtract(const LongInt& rhs) const {
    Deque<char> resultrhs = this->digits;
    Deque<char> resultlhs = rhs.digits;
    string str = "";
    LongInt result;
    int maxsize = max(resultrhs.size(), resultlhs.size());

    int i = 0;
    int borrow = 0;
    for (; i < maxsize; i++) {
        //pop digit
        int i1 = resultlhs.removeBack() - 48;
        int i2 = resultrhs.removeBack() - 48;
        resultlhs.addFront(48);
        resultrhs.addFront(48);
        int sum = 0;

        if (i1 < i2) {
            sum = (i1 + 10 - i2 - borrow) % 10;
            borrow = 1;
        } else {
            sum = i1 - i2 - borrow;
            if (sum < 0) {
                sum = sum + 10;
                borrow = 1;
            } else
                borrow = 0;
        }
        str = string(1, 48 + sum) + str;
    }

    LongInt returnDeque;
    for (int i = 0; i < str.length(); i++)
        returnDeque.digits.addBack(str[i]);
    returnDeque.remove0s();

    return returnDeque;
}

//Implemented the logical binary operators (<, <=, >, >=, ==, !=)
bool LongInt::operator<(const LongInt & rhs) const {
    return compareTo(rhs) < 0;
}

bool LongInt::operator<=(const LongInt & rhs) const {
    return compareTo(rhs) <= 0;

}

bool LongInt::operator>(const LongInt & rhs) const {
    return compareTo(rhs) > 0;
}

bool LongInt::operator>=(const LongInt & rhs) const {
    return compareTo(rhs) >= 0;
}

bool LongInt::operator==(const LongInt & rhs) const {
    return compareTo(rhs) == 0;
}

bool LongInt::operator!=(const LongInt & rhs) const {
    return compareTo(rhs) != 0;
}

//Made a private function called compareTo, to check the sizes of the integers.
//Compare their deque elements from the front as removing them. 
//The operand with a larger deque element is a larger integer in a positive sign 
//but a smaller integer in a negative sign.

int LongInt::compareTo(const LongInt & rhs) const {
    int size1 = digits.size(); //left
    int size = rhs.digits.size();

    if (size1 < size) {
        if (rhs.negative)return 1; //also checks if the rhs value is negative
        else return -1;
    } else if (size1 > size) {
        if (negative)return -1;
        else return 1;
    } else if (size1 == size) {//checks the signs if two sizes are the same
        if (!negative && rhs.negative)
            return 1;
        else if (negative && !rhs.negative)
            return -1;
    }
    Deque<char> newLhs = digits;
    Deque<char> newRhs = rhs.digits;
    for (int i = 0; i < newLhs.size(); i++) {
        char c1 = newLhs.removeFront();
        char c2 = newRhs.removeFront();
        newLhs.addBack(c1);
        newRhs.addBack(c2);
        if (c1 > c2) {
            if (!negative && !rhs.negative)
                return 1;
            else
                return -1;

        } else if (c1 > c2) {
            if (!negative && !rhs.negative)
                return -1;
            else
                return 1;

        }

    }
    return -1;
}





