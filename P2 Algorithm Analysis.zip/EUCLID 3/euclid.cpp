/*
 * CHELSEA IP
 * 10/15/2018
 * This program uses the Euclidean algorithm to find the greatest common divisor
 * for two nonnegative integers. GCD is computed by repetitions of the following
 * three statements: R=A mod B; A=B; B=R; until B becomes zero.
 */
#include <iostream>
#include <sys/time.h>

using namespace std;

int numOfMod = 0;

int gcd(int a, int b) { //this is my euclidean algorithm

    int r;

    if (a < b) {    //special case when a is less than b
        int temp = a;
        a = b;
        b = temp;
    }
    while (b != 0) { //iterative version
        r = a % b;
        a = b;
        b = r;
        numOfMod++; //increments the number of modulus operations
    }

    int gcdStore = a; // Store the result of our GCD
    return gcdStore; // Return the number of modulo operations
}

/**
 * Loops through the GCDs of a series of integer pairs below n and determine the one with the most
 * modulo operations required to get its result. 
 */
//void startEuclid(std::map<int, int>& complx_ref) {


//}

int main() {


    // Allows user to enter input value
    int n;
    cout << "Enter max n: ";
    cin >> n;

    struct timeval startTime, endTime;

    double t;

    int mod_max = 0;
    int maxOfA = 0;
    int maxOfB = 0;
    int maxGcd = 0;
    gettimeofday(&startTime, NULL);  //start time

    for (int a = 8; a < n; a++) // Iterate through all n - 1
    {
        for (int b = a + 1; b <= n; b++) // b is always a +1
        {

            int numOfGcd = gcd(a, b);

            if (numOfMod > mod_max) {
                maxOfA = a; //update a and b
                maxOfB = b;
                maxGcd = numOfGcd; //update number of gcd
                mod_max = numOfMod;
                cout << "i = "<< maxOfA << " j = "<< maxOfB <<" gcd = "<< maxGcd<<" number of modulus = " << mod_max <<endl;
            }
            if (numOfMod <= mod_max) {
                numOfMod = 0; //reset num of modulus
            }

        }



    }
    gettimeofday(&endTime, NULL); //records end time of the loops
    t = (endTime.tv_sec - startTime.tv_sec)*1000000 + (endTime.tv_usec - startTime.tv_usec); //gettime



    //print statement for modulus operations, time required, gcd and input
    cout << "n = " << n << " gcd(" << maxOfA << ", " << maxOfB << ") = " << maxGcd << " took "
            << mod_max << " modulus operations ...time required = " << t << "ms" << endl;

}
