/*
 * Chelsea Ip Tze Hwan
 * Programming Assignment #4
 * Muneheiro Fukuda
 * November 5, 2018
 * This is a non recursive merge sort implementation using vectors a and b. The program
 * uses only one additional array, sorts partial data items and merges the original data into the additional array.
 * We are also comparing the performance to the ordinary mergesort and quicksort. I found that the mergesort is much
 * slower than quick sort although their running time is upper bounded to O(n log n).
 */

#include <vector>
#include <math.h> 
using namespace std;

template <class Comparable>

//merges two sorted array segments into a temporary array 
void merge(vector<Comparable> &a, vector<Comparable> &b, int first, int middle, int last) {
    int k = first, i = first, j = middle + 1; //initialize the local indices to indicate the subarrays

    //loop till there are no more elements
    while (i <= middle && j <= last) { //while two subarrays are not empty, copy the smaller item into temporary array
        if (a[i] < a[j]) { 
            b[k++] = a[i++];
        } else {
            b[k++] = a[j++];
        }
    }

    while (i <= middle) //exhaust to the left array
        b[k++] = a[i++];
    while (j <= last) //exhaust to the last array
        b[k++] = a[j++];
}

template <class Comparable>
//Iteratively sort array using temporary array
void mergesort(vector<Comparable> &a) {

    int size = a.size();
    vector<Comparable> b(size); // this is only one temporary array.
    int low = 0;
    int high = a.size() - 1;
   
    for (int nItems = 1; nItems <= high - low; nItems = 2 * nItems) {
        int i;
        for (int i = low; i < size; i += 2 * nItems) { //combine pairs of array of nItems * nItems
            int first = i;
            int middle = i + nItems - 1;
            int last = min(i + 2 * nItems - 1, high);

            merge(a, b, first, middle, last); //sort them into one

        }
        //write them back to the original array in sorted order
        for (i = 0; i < a.size(); i++)
            a[i] = b[i];

    }

}

