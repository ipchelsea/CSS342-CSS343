/*
 * weight.h
 *
 *  Created on: 3 Oct 2018
 *      Author: chelseaiptzehwan
 */

#ifndef WEIGHT_H_
#define WEIGHT_H_
#include <iostream>
using namespace std;

typedef int Pounds; //used to create an alias name for another data type
typedef int Ounces;

class Weight {

public:

	//constructor(default is 0 lb and 0 oz)
	Weight(Pounds x = 0, Ounces y = 0);
	Weight(int lbs);

	int convertTo(const Weight&) const;
	int compareTo(const Weight&) const;
	Weight add(const Weight&) const;
	Weight substract(const Weight&) const;
	Weight multiply(const Weight&)const;
	double divide(const Weight&) const;
	Weight divide(const double&) const;

	//method to get the value of the data field
	Pounds getPounds();
	Ounces getOunces();


	//define function operators for augmented operators
	Weight operator +=(const Weight&);
	Weight operator -=(const Weight&);
	Weight operator *=(const Weight&);
	Weight operator /=(const Weight&) const;

	//define function operators for arithmetic operators
	Weight operator +(const Weight&) const;
	Weight operator -(const Weight&) const;
	Weight operator *(const double) ;
	Weight operator /(const Weight&) const;
	Weight operator =(const Weight&) const;

	//define function operators for unary + and -
	Weight operator -() const;

	//define the << and >> operators
	friend ostream& operator <<(ostream& outstream, const Weight& Weight);
	friend istream &operator >>(istream& input, Weight& Weight);

	//define function operators for relational operators
	bool operator ==(const Weight&) const;
	bool operator !=(const Weight&) const;
	bool operator <(const Weight&) const;
	bool operator <=(const Weight&) const;
	bool operator >(const Weight&) const;
	bool operator >=(const Weight&) const;

private:
	int lbs;
	int ozs;
	void compareTo();	//reduces ounces in up to 16 ounces

};

#endif /* Weight_H_ */

