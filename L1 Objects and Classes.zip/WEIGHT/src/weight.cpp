//============================================================================
// Name        : WEIGHT.cpp
// Author      : Chelsea Ip Tze Hwan
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "weight.h"
#include <sstream>

Weight::Weight(Pounds x, Ounces y) :lbs(x), ozs(y) {
	convertTo(*this);
}
int Weight::Weight(int lbs) {
	return ozs + (lbs * 16);
}
int Weight::getPounds() {
	return lbs;
}

int Weight::getOunces() {
	return ozs;
}

int Weight::convertTo(const Weight&) const { //1 pound = 16 ozs
	return ozs + (lbs * 16);
}

ostream& operator<<(ostream& out, const Weight& other) {
	if (other.lbs == 1)
		out << other.lbs;
	else if (other.ozs == 1)
		out << other.ozs;
	return out;
}

istream & operator>>(istream & in, Weight & other) {
	cout << "Enter Pounds: ";
	in >> other.lbs;

	cout << "Enter Ounces: ";
	in >> other.ozs;
	return in;
}

Weight Weight::operator-() const { //unary operator
	int x = this->lbs * -1;
	int y = this->ozs * -1;
	x += (y / 16);
	y = y % 16;
	return Weight(x, y);
}

Weight Weight::add(const Weight& other) const { //addition
	int x = this->lbs + other.lbs;
	int y = this->ozs + other.ozs;
	x += (y / 16);
	y = y % 16;
	return Weight(x, y);
}

Weight Weight::operator+=(const Weight& other) { //augmented operator addition
	*this = add(other);
	return *this;

}

Weight Weight::substract(const Weight& other) const { //subtraction
	int x = this->lbs - other.lbs;
	int y = this->ozs - other.ozs;
	x += (y / 16);
	y = y % 16;
	return Weight(x, y);
}
Weight Weight::operator -=(const Weight& other) { //augmented operator subtraction
	*this = substract(other);
	return *this;

}

Weight Weight::multiply(const Weight& num) const { //multiplication
	int x = this->lbs * num.lbs;
	int y = this->ozs * num.ozs;
	x += (y / 16);
	y = y % 16;
	return Weight(x, y);

}

Weight Weight::operator *=(const Weight& other) { //augmented operator multiplication
	*this = multiply(other);
	return *this;

}

double Weight::divide(const Weight&other) const { //division
	int x = convertTo(*this);
	int y = convertTo(other); //dereference the pointer and gets the value there
	if (x == 0 || y == 0) {
		std::cout << "Division by zero error" << std::endl;
	}
	return x / y;
}

Weight Weight::divide(const double& other) const {
	int x = convertTo(*this);
	if (x == 0) {
		std::cout << "Division by zero error" << std::endl;
	}
	return Weight(0, x / other);
}
Weight Weight::operator/=(const Weight& other) const {
	*this = divide(other);
	return *this;

}

int Weight::compareTo(const Weight& other) const {
	int a = convertTo(*this);
	int b = convertTo(other); //converting to ounces then subtracting it to check
	int z = a - b;
	if (z < 0) {
		return -1;
	} else if (z == 0) {
		return 0;
	} else {
		return 1;
	}

}

//Define function operators for comparison operators
bool operator >(const Weight& s1, const Weight& s2) const {
	return s1.compareTo(s2) > 0;
}

bool operator >=(const Weight& s1, const Weight& s2) const {
	return s1.compareTo(s2) >= 0;

}

bool operator <(const Weight& s1, const Weight& s2) const {
	return s1.compareTo(s2) < 0;
}

bool operator <=(const Weight& s1, const Weight& s2) const {
	return s1.compareTo(s2) <= 0;
}
bool operator ==(const Weight& s1, const Weight& s2) const {
	return s1.compareTo(s2) == 0;
}
bool operator !=(const Weight& s1, const Weight& s2) const {
	return s1.compareTo(s2) != 0;
}

//Define non member function operators for arithmetic functions
Weight operator+(const Weight& s1, const Weight& s2) {
	return s1.add(s2);
}
Weight operator-(const Weight& s1, const Weight& s2) {
	return s1.substract(s2);
}
Weight operator*(const Weight& s1, const Weight& s2) {
	return s1.multiply(s2);
}
Weight operator/(const Weight& s1, const Weight& s2) {
	return s1.divide(s2);
}

