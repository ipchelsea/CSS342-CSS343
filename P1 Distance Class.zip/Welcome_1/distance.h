/*
 * CHELSEA IP TZE HWAN
 * CSS342
 * Program 1: A Distance
 * Date: 10/09/2018
 * This header file consists of a Distance class presenting a distance in feet and inches.
 * Some of the features include a type conversion, member functions(getFeet, getInch), Math operators(addition,
 * subtraction, multiplication, and division), comparison operators, assignment operators and
 * implementing the << and >> operators.
 * 
 */

#ifndef DISTANCE_H_
#define DISTANCE_H_
#include <iostream>
using namespace std;

typedef int Feet;
typedef int Inch;

class Distance {
    ////define the << and >> operators
    friend ostream& operator<<(ostream& outstream, const Distance& Distance);
    friend istream& operator>>(istream& input, Distance& Distance);

public:


    Distance(Feet x = 0, Inch y = 0);

    //get methods
    Feet getFeet() const;
    Inch getInch() const;

    // Set methods
    void setFeet(Feet); // optional
    void setInch(Inch); // optional

    // Arithmetic operators
    Distance operator+(const Distance&) const;
    Distance operator-(const Distance&) const;
    double operator*(const Distance&) const;
    double operator/(const Distance&) const;
    Distance operator/(const double) const;
    Distance operator-() const;

    // Boolean comparison operators
    bool operator==(const Distance&) const;
    bool operator!=(const Distance&) const;
    bool operator>(const Distance&) const;
    bool operator<(const Distance&) const;
    bool operator>=(const Distance&) const;
    bool operator<=(const Distance&) const;

    // Assignment operators
    Distance& operator+=(const Distance&);
    Distance& operator-=(const Distance&);
    Distance& operator*=(const double);
    Distance& operator/=(const double);

private:
    Feet ft;
    Inch inch;

    void reduce();
};



#endif /* DISTANCE_H_ */
