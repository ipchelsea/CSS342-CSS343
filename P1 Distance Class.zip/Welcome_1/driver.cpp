/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * driver.cpp
 *
 *  Created on: 8 Oct 2018
 *      Author: chelseaiptzehwan
 */
//writing my own test cases

#include "Distance.h"
#include <iostream>
using namespace std;

int main( )
{
  //create and initialize 5 numbers(w1,w2,w3,w4,w5)
  Distance d1( -2, 35 ), d2(8, -35 ), d3( 3, 7 ), d4( 2 ), d5;

  cout << "d1 = " << d1 << endl;//test 
  cout << "d2 = " << d2 << endl;
  cout << "d3 = " << d3 << endl;
  cout << "d4 = " << d4 << endl;
  cout << "d5 = " << d5 << endl;

  cout << "Square feet( d1 * d2 ) = " << d1 * d2 << endl; //testing addition
  cout << "d2 / d3 = " << d2 / d3 << endl; //testing division
  cout << "( d1 += d3 ) = " << ( d1 += d3 ) << endl;//testing addition augmented operator

  cout << "d1 <= d2 is " << ( ( d1 <= d2 ) ? "true" : "false" ) << endl;//tests comparison operators
  cout << "d2 >= d3 is " << ( ( d2 >= d3 ) ? "true" : "false" ) << endl;
}
