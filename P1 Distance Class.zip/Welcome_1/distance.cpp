/*
 * This source file defines member functions, constructor, arithmetic operators, comparison operators,
 * assignment operators.
 * Convert feet to inches, 1 feet = 12 inches.
 */

#include "Distance.h"
#include <iostream>
#include <sstream>


//------------------------------- Distance -----------------------------------
// Constructor: the default is 0 feet 0 inch
Distance::Distance( Feet x, Inch y ) : ft( x ), inch( y ) {
  reduce( );
}

//------------------------------- Member functions ---------------------------
//--------------------------------  get methods ------------------------------
Feet Distance::getFeet( ) const {
  return ft;
}

Inch Distance::getInch( )const {
  return inch;
}

//--------------------------------  set methods ------------------------------
void Distance::setFeet( Feet argFeet ) {
  ft = argFeet;
}

void Distance::setInch( Inch argInch ) {
  inch = argInch;
}

//------------------------------------- + ------------------------------------
// Overloaded +: addition of 2 Distances, current object and parameter

Distance Distance::operator+( const Distance& rhs ) const {
  Distance sum;

  sum.ft = ft + rhs.ft;
  sum.inch = inch + rhs.inch;
  sum.reduce( );

  return sum;
}

//------------------------------------- - ------------------------------------
// Overloaded -: subtraction of 2 Distances, current object and parameter

Distance Distance::operator-( const Distance& rhs ) const {
  Distance sub;

  sub.ft = ft - rhs.ft;
  sub.inch = inch - rhs.inch;
  sub.reduce( );

  return sub;
}

//------------------------------------- * ------------------------------------
// Overloaded *: multiplication of 1 Distance by an integer.

double Distance::operator*( const Distance& s) const {
  
  double inchValue;

  inchValue = double((ft * 12 + inch) * (s.getFeet() * 12 + s.getInch()));

  return ((double) inchValue / (double) 12) /  12.0;
}

//------------------------------------- / ------------------------------------
// Overloaded /: division of 2 Distances, current object and parameter

double Distance::operator/( const Distance& rhs ) const {
  Inch lhsinch;
  Inch rhsinch;
  double div = 0.0;

  lhsinch = ft * 12 + inch;
  rhsinch = rhs.ft * 12 + rhs.inch;

  if ( rhsinch == 0 )
    cerr << "zero division!!" << endl;

  div = double( lhsinch ) / double( rhsinch );

  return div;
}

//------------------------------------- / ------------------------------------
// Overloaded /: division of 1 Distance by an integer.

Distance Distance::operator/( const double rhs ) const {
  Inch inchValue = ft * 12 + inch;

  if ( rhs == 0.0 )
    cerr << "zero division!!" << endl;

  inchValue = int( double( inchValue ) / rhs );

  Distance result;
  result.ft = inchValue / 12;
  result.inch = inchValue % 12;

  return result;
}

//------------------------------------- == -----------------------------------
// Overloaded ==: return true if this object == parameter, otherwise false

bool Distance::operator==( const Distance& rhs ) const {
  return ft == rhs.ft && inch == rhs.inch;
}

//------------------------------------- != -----------------------------------
// Overloaded !=: return true if this object != parameter, otherwise false

bool Distance::operator!=( const Distance& rhs ) const {
  return ( *this == rhs ) ? false : true;
}

//------------------------------------- > ------------------------------------
// Overloaded >: return true if this object > parameter, otherwise false

bool Distance::operator>( const Distance& rhs ) const {
  return ft > rhs.ft || ( ft == rhs.ft && inch > rhs.inch );
}

//------------------------------------- < ------------------------------------
// Overloaded <: return true if this object < parameter, otherwise false

bool Distance::operator<( const Distance& rhs ) const {
  return ft < rhs.ft || ( ft == rhs.ft && inch < rhs.inch );
}

//------------------------------------- >= -----------------------------------
// Overloaded >=: return true if this object >= parameter, otherwise false

bool Distance::operator>=( const Distance& rhs ) const {
  return *this > rhs || *this == rhs;
}

//------------------------------------- <= -----------------------------------
// Overloaded <=: return true if this object <= parameter, otherwise false

bool Distance::operator<=( const Distance& rhs ) const {
  return *this < rhs || *this == rhs;
}

//------------------------------------- += -----------------------------------
// Overloaded +=: this object += parameter

Distance& Distance::operator+=( const Distance& rhs ) {
  ft += rhs.ft;
  inch += rhs.inch;
  reduce( );

  return *this;
}

//------------------------------------- -= -----------------------------------
// Overloaded -=: this object -= parameter

Distance& Distance::operator-=( const Distance& rhs ) {
  ft -= rhs.ft;
  inch -= rhs.inch;
  reduce( );

  return *this;
}

//------------------------------------- *= -----------------------------------
// Overloaded *=: this object *= a double parameter

Distance& Distance::operator*=( const double rhs ) {
  Inch inchValue;
  inchValue = int( double( ft * 12 + inch ) * rhs );
  ft = inchValue / 12;
  inch = inchValue % 12;

  return *this;
}

//------------------------------------- /= -----------------------------------
// Overloaded /=: this object /= a double parameter

Distance& Distance::operator/=( const double rhs ) {
  Inch inchValue = ft * 12 + inch;

  if ( rhs == 0.0 )
    cerr << "zero division!!" << endl;

  inchValue = int( double( inchValue ) / rhs );

  ft = inchValue / 12;
  inch = inchValue % 12;

  return *this;
}

//------------------------------------ negation - ----------------------------
// Negation -

Distance Distance::operator-( ) const {
  Distance negate;

  negate.ft = -ft;
  negate.inch = -inch;

  return negate;
}

//implementing the << and >> operators
//------------------------------------- << -----------------------------------
ostream& operator<<( ostream& output, const Distance& w ) {
  switch( w.ft ) {
  case 1:
  case -1:
    output << w.ft << " ft ";
    break;
  case 0:
    break;
  default:
    output << w.ft << " ft ";
    break;
  }

  switch( w.inch ) {
  case 1:
  case -1:
    output << w.inch << " inch ";
    break;
  case 0:
    if ( w.ft == 0 )
      output << "0 inch";
    break;
  default:
    output << w.inch << " inch ";
    break;
  }
  return output;
}

//------------------------------------- >> -----------------------------------
istream& operator>>( istream& input, Distance& w ) {

  double inFeet, inInch;
  input >> inFeet >> inInch;
  w.ft = int( inFeet );
  w.inch = int( inInch );
  w.reduce( );
  return input;
}

//------------------------------- reduce -------------------------------------
// reduce: reduce inch into up to 12 inch

void Distance::reduce( ) {

  ft += inch / 12;
  inch %= 12;
  if (ft > 0 && inch < 0) {
    --ft;
    inch = 12 + inch;
  } else if ( ft < 0 && inch > 0 ) {
    ++ft;
    inch = -12 + inch;
  }
}


