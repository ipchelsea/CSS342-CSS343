
/*
 * Chelsea Ip 
 * Programming Assignment #6
 * CSS 342
 * Munehiro Fukuda
 * November 24, 2018
 * This programming assignment implements the unary operators and the operator "=" in my calculator.
 * The calculator is also able to handle 3 variables namely, variables a,b and c. The unary operators
 * (!, ~, +, -) are located in a separated method from the binary method but repeats similar operation.
 * Inserted unaryOp(TokenType topOp) under binary Op for evaluator.h.
 * Whenever we pop out a value from postFixStack, we also need to do the same in the postFixVarStack. This
 * applies to the corresponding characters ('a', 'b', 'c'). We want to make sure both stacks have the
 * same number of tokens in it.
 */

// Public routine that performs the evaluation. Examines the postfix machine
// to see if a single result is left and if so, return it; otherwise prints
// error.

template<class NumericType>
NumericType Evaluator<NumericType>::getValue() {

    Tokenizer<NumericType> tok(str);
    Token<NumericType> lastToken;

    do {
        lastToken = tok.getToken();
        processToken(lastToken);
    } while (lastToken.getType() != EOL);

    if (postFixStack.empty()) {
        cerr << "Missing operand!" << endl;
        return 0;
    }

    NumericType theResult = postFixStack.back();
    postFixStack.pop_back();
    if (!postFixStack.empty())
        cerr << "Warning: missing operators!" << endl;

    return theResult;
}

// After token is read, use operator precedence parsing algorithm to process
// it; missing opening parentheses are detected here.

template<class NumericType>
void Evaluator<NumericType>::
processToken(const Token<NumericType> &lastToken) {
    TokenType topOp;
    TokenType lastType = lastToken.getType();

    //adds three case statements, each corresponding to VAR_A, VAR_B and VAR_C, pushing the
    //variable content into postFixStack and the variable name into postFixVarStack.
    //Push a space to postFixVarStack.
    switch (lastType) {
        case VALUE:
            postFixStack.push_back(lastToken.getValue());
            postFixVarStack.push_back(' ');
            return;

        case VAR_A:
            postFixStack.push_back(var_a);
            postFixVarStack.push_back('a');
            return;

        case VAR_B:
            postFixStack.push_back(var_b);
            postFixVarStack.push_back('b');
            return;

        case VAR_C:
            postFixStack.push_back(var_c);
            postFixVarStack.push_back('c');
            return;

            //automatically goes to the unary operator method when (!, ~, + or -) is read.
        case CPAREN:
            while ((topOp = opStack.back()) != OPAREN &&
                    topOp != EOL) {
                if (topOp == BIT_COMP || topOp == UN_MINUS || topOp == UN_PLUS || topOp == NOT)
                    unaryOperator(topOp);
                else
                    binaryOp(topOp);
            }

            if (topOp == OPAREN)
                opStack.pop_back();
            else
                cerr << "Missing open parenthesis" << endl;
            break;

        default: // general operator case
            while (PREC_TABLE[ lastType ].inputSymbol <=
                    PREC_TABLE[ topOp = opStack.back() ].topOfStack) {
                if (topOp == BIT_COMP || topOp == UN_MINUS || topOp == UN_PLUS || topOp == NOT)
                    unaryOperator(topOp);
                else
                    binaryOp(topOp);
            }
            if (lastToken.getType() != EOL)
                opStack.push_back(lastType);

            break;

    }

}

//Takes the left hand side operator off the postFixStack,applying the operator
//then pushing the result. Method will print "Unbalanced Parenthesis" if there
//is a missing closed parenthesis or division by zero is attempted.
//Pushes the variable content in postFixStack and the variable name in postFixVarStack.

template<class NumericType>
void Evaluator<NumericType>::unaryOperator(TokenType topOp) {
    if (topOp == OPAREN) {
        cerr << "Unbalanced parenthesis" << endl;
        opStack.pop_back();
        return;
    }
    NumericType lhs = getTop();
    postFixVarStack.pop_back();
    if (topOp == UN_PLUS) //+
        postFixStack.push_back(lhs);
    else if (topOp == UN_MINUS)
        postFixStack.push_back(-lhs); //-
    else if (topOp == NOT)
        postFixStack.push_back(!lhs); //!
    else if (topOp == BIT_COMP)
        postFixStack.push_back(~lhs); //~
    opStack.pop_back();
    postFixVarStack.push_back(' ');
}


// Process an operator by taking two items off the postfix stack, applying
// the operator, and pushing the result.
// Print error if missing closing parenthesis or division by 0.
// Pushes variable content in PostFixStack and the variable name in PostFixVarStack

template<class NumericType>
void Evaluator<NumericType>::binaryOp(TokenType topOp) {
    if (topOp == OPAREN) {
        cerr << "Unbalanced parenthesis" << endl;
        opStack.pop_back();
        return;
    }
    NumericType rhs = getTop();
    NumericType lhs = getTop();
    postFixVarStack.pop_back();
    // the original operators
    if (topOp == PLUS)
        postFixStack.push_back(lhs + rhs);
    else if (topOp == MINUS)
        postFixStack.push_back(lhs - rhs);
    else if (topOp == MULT)
        postFixStack.push_back(lhs * rhs);
    else if (topOp == DIV)
        if (rhs != 0)
            postFixStack.push_back(lhs / rhs);
        else {
            cerr << "Division by zero" << endl;
            postFixStack.push_back(lhs);
        }// C++ operators
    else if (topOp == MODULUS)
        postFixStack.push_back(lhs % rhs);
    else if (topOp == SHIFT_L)
        postFixStack.push_back(lhs << rhs);
    else if (topOp == SHIFT_R)
        postFixStack.push_back(lhs >> rhs);
    else if (topOp == LT)
        postFixStack.push_back(lhs < rhs);
    else if (topOp == LE)
        postFixStack.push_back(lhs <= rhs);
    else if (topOp == GT)
        postFixStack.push_back(lhs > rhs);
    else if (topOp == GE)
        postFixStack.push_back(lhs >= rhs);
    else if (topOp == EQUAL)
        postFixStack.push_back(lhs == rhs);
    else if (topOp == NOTEQUAL)
        postFixStack.push_back(lhs != rhs);
    else if (topOp == BIT_AND)
        postFixStack.push_back(lhs & rhs);
    else if (topOp == BIT_EOR)
        postFixStack.push_back(lhs ^ rhs);
    else if (topOp == BIT_IOR)
        postFixStack.push_back(lhs | rhs);
    else if (topOp == LOG_AND)
        postFixStack.push_back(lhs && rhs);
    else if (topOp == LOG_OR)
        postFixStack.push_back(lhs || rhs);
    else if (topOp == ASSIGN) {
        
        if (lhs == var_a) {
            var_a = rhs; 
            postFixVarStack.push_back('a');
            postFixStack.push_back(var_a);
        } else if (lhs == var_b) {
            var_b = rhs;
            postFixVarStack.push_back('b');
            postFixStack.push_back(var_b);
        } else if (lhs == var_c) {
            var_c = rhs;
            postFixVarStack.push_back('c');
            postFixStack.push_back(var_c);
        }
    }
    opStack.pop_back();
    postFixVarStack.push_back(' ');
}

// top and pop the postfix machine stack; return the result.
// If the stack is empty, print an error message.

template<class NumericType>
NumericType Evaluator<NumericType>::getTop() {
    if (postFixStack.empty()) {
        cerr << "Missing operand" << endl;
        return 0;
    }

    NumericType tmp = postFixStack.back();
    postFixStack.pop_back();
    return tmp;
}
